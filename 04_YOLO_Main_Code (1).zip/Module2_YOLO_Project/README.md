# Real-Time YOLO Object Detection and Performance Analysis

Academic project for Module 2 - Option 5: **Object Detection**.

The project implements a practical real-time object detection pipeline using the Ultralytics YOLO Python API and OpenCV. It accepts image, video, or webcam input and records performance metrics such as inference latency, frame rate, detection count, and mean confidence.

## Project structure

```text
Module2_YOLO_Project/
├── src/
│   ├── config.py
│   ├── detector.py
│   ├── io_utils.py
│   ├── metrics.py
│   ├── overlay.py
│   ├── reporting.py
│   └── main.py
├── tests/
│   └── test_metrics.py
├── docs/
├── assets/
├── results/
├── weights/
├── requirements.txt
├── README.md
└── LICENSE-NOTICE.txt
```

## 1. Create an environment

Windows PowerShell:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Linux/macOS:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Ultralytics documents `pip install -U ultralytics` for installation and supports image, video, and webcam sources through its Python/CLI interfaces. The project keeps the model path configurable so a compatible checkpoint can be substituted when required by the lab environment.

## 2. Run on an image

```bash
python -m src.main --source path/to/image.jpg --model yolo26n.pt --run-name image_demo
```

## 3. Run on a video

```bash
python -m src.main --source path/to/video.mp4 --model yolo26n.pt --run-name video_demo
```

## 4. Run on webcam

```bash
python -m src.main --source 0 --model yolo26n.pt --run-name webcam_demo
```

Press `q` or `Esc` to stop a live stream.

## 5. Headless / benchmark-style execution

```bash
python -m src.main --source path/to/video.mp4 --model yolo26n.pt --run-name benchmark_01 --no-display --max-frames 300
```

## Output artifacts

Each run creates a directory such as:

```text
outputs/benchmark_01/
├── annotated_output.mp4
├── metrics.csv
├── summary.json
└── plots/
    ├── fps_over_frames.png
    ├── inference_latency.png
    └── detections_per_frame.png
```

These artifacts support the report's experimental analysis. The program measures the actual execution environment; do not copy example values into the final report.

## 6. Tests

The metric layer can be tested without downloading model weights:

```bash
python -m pytest -q
```

## Evaluation metrics

- **Inference latency (ms):** time spent in one model inference call.
- **FPS:** reciprocal of frame-to-frame processing interval after the first frame.
- **Mean confidence:** average confidence across detections for a frame/run.
- **Detections per frame:** total detected bounding boxes per frame.
- **P95 latency:** 95th percentile inference latency, useful for understanding tail behavior.

## Notes on reproducibility

Model speed depends on CPU/GPU, RAM, input resolution, driver/runtime configuration, source resolution, and the selected checkpoint. Results should therefore be reported together with the hardware/software setup and test configuration.

## Academic scope

The accompanying assignment report provides a documented comparison of YOLO, SSD, and Faster R-CNN. The implementation focuses on YOLO for the project component, matching the Module 2 Option 5 specification.
