# Model Weights

Model checkpoint files are intentionally not included in the submission source archive.

The application accepts a model path through `--model`, for example:

```bash
python -m src.main --source path/to/video.mp4 --model yolo26n.pt --run-name baseline
```

A compatible Ultralytics checkpoint can also be placed in this directory and referenced by file path:

```bash
python -m src.main --source path/to/video.mp4 --model weights/my_model.pt --run-name local_model
```

The checkpoint must be compatible with the installed Ultralytics runtime.
