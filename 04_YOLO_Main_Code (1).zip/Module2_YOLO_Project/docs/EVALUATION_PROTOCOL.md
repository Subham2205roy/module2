# Evaluation Protocol

## Purpose

The analysis component evaluates the real-time behavior of the selected YOLO checkpoint under controlled changes in image size and confidence threshold.

## Fixed test procedure

1. Use the same input video for every run.
2. Use the same model checkpoint for every run.
3. Process a fixed number of frames, for example 300.
4. Run the tests on the same computer without other heavy workloads.
5. Record CPU/GPU, RAM, operating system, Python version, model checkpoint, image size, confidence threshold, and number of frames.
6. Save `metrics.csv` and `summary.json` for each run.

## Suggested experiments

| Run | Image size | Confidence | Purpose |
|---|---:|---:|---|
| A | 640 | 0.25 | Baseline |
| B | 512 | 0.25 | Lower input size |
| C | 320 | 0.25 | Speed-oriented configuration |
| D | 640 | 0.50 | More conservative detections |

The exact measured FPS and latency must be obtained by running the program on the target machine. Do not replace measured values with numbers from another computer.

## Core metrics

### Average inference latency

Average of all recorded per-frame inference times.

### P95 latency

The latency below which 95% of measured inference calls fall. This helps expose occasional slow frames.

### Average FPS

Mean of frame-rate measurements after the first processed frame.

### Mean confidence

Average confidence across non-empty detection frames.

### Average detections per frame

Mean number of bounding boxes produced per frame.

## Interpretation guide

- Lower latency indicates less time spent per model inference.
- Higher FPS indicates more frames processed per second.
- A larger input size can improve spatial detail but generally increases computation.
- A higher confidence threshold can reduce low-confidence detections but may also remove valid objects.
- A comparison is meaningful only when hardware and test data are kept constant.
