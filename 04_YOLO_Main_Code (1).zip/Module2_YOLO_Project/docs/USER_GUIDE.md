# User Guide

## Recommended first run

Use a short road-traffic video with visible cars, people, and other common objects.

```bash
python -m src.main --source data/traffic.mp4 --model yolo26n.pt --run-name baseline --max-frames 300
```

## Recommended benchmark matrix

```bash
python -m src.main --source data/traffic.mp4 --model yolo26n.pt --imgsz 640 --conf 0.25 --run-name imgsz640_conf025 --no-display --max-frames 300
python -m src.main --source data/traffic.mp4 --model yolo26n.pt --imgsz 512 --conf 0.25 --run-name imgsz512_conf025 --no-display --max-frames 300
python -m src.main --source data/traffic.mp4 --model yolo26n.pt --imgsz 320 --conf 0.25 --run-name imgsz320_conf025 --no-display --max-frames 300
python -m src.main --source data/traffic.mp4 --model yolo26n.pt --imgsz 640 --conf 0.50 --run-name imgsz640_conf050 --no-display --max-frames 300
```

## Webcam

```bash
python -m src.main --source 0 --model yolo26n.pt --run-name webcam_test
```

## Output review

Open the run directory and inspect:

- `annotated_output.mp4` for detection visualization.
- `metrics.csv` for per-frame measurements.
- `summary.json` for aggregate metrics.
- `plots/` for latency, FPS, and detection-count graphs.

## Troubleshooting

### `ModuleNotFoundError: ultralytics`

Activate the project environment and run:

```bash
pip install -r requirements.txt
```

### Model weight not found

The first inference run may download the selected pretrained checkpoint when a network connection is available. Alternatively, supply a local compatible checkpoint:

```bash
python -m src.main --source data/traffic.mp4 --model weights/my_model.pt --run-name local_model
```

### Webcam does not open

Try another index:

```bash
python -m src.main --source 1 --model yolo26n.pt --run-name webcam_1
```

On Windows, also verify camera privacy settings and that no other application is holding the camera.
