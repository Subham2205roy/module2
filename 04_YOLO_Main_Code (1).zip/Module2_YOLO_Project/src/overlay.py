from __future__ import annotations

import cv2


def add_metrics_overlay(frame, fps: float, inference_ms: float, detections: int, conf: float):
    h, _ = frame.shape[:2]
    panel_h = 74
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (430, panel_h), (20, 20, 20), -1)
    frame = cv2.addWeighted(overlay, 0.82, frame, 0.18, 0)

    text_lines = [
        f"FPS: {fps:5.1f}",
        f"Inference: {inference_ms:6.1f} ms",
        f"Objects: {detections:3d}   Mean conf: {conf:.2f}",
    ]
    y = 22
    for line in text_lines:
        cv2.putText(frame, line, (12, y), cv2.FONT_HERSHEY_SIMPLEX, 0.53, (235, 235, 235), 1, cv2.LINE_AA)
        y += 23
    return frame
