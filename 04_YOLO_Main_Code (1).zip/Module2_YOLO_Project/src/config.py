from dataclasses import dataclass
from pathlib import Path

DEFAULT_MODEL = "yolo26n.pt"
DEFAULT_IMAGE_SIZE = 640
DEFAULT_CONFIDENCE = 0.25
DEFAULT_IOU = 0.70
DEFAULT_OUTPUT_ROOT = Path("outputs")


@dataclass
class AppConfig:
    model: str = DEFAULT_MODEL
    imgsz: int = DEFAULT_IMAGE_SIZE
    conf: float = DEFAULT_CONFIDENCE
    iou: float = DEFAULT_IOU
    device: str = "auto"
    max_frames: int | None = None
    save_output: bool = True
    display: bool = True

    def output_dir(self, root: Path, run_name: str) -> Path:
        return root / run_name
