from __future__ import annotations

import argparse
import time
from pathlib import Path

import cv2

from .config import DEFAULT_CONFIDENCE, DEFAULT_IMAGE_SIZE, DEFAULT_IOU, DEFAULT_MODEL
from .detector import YOLODetector
from .io_utils import create_video_writer, ensure_dir, parse_source
from .metrics import MetricsTracker
from .overlay import add_metrics_overlay
from .reporting import save_metrics_csv, save_plots, save_summary


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Real-time YOLO object detection and performance analysis system."
    )
    parser.add_argument("--source", required=True, help="Image/video path or webcam index such as 0")
    parser.add_argument("--model", default=DEFAULT_MODEL, help="YOLO checkpoint, e.g. yolo26n.pt")
    parser.add_argument("--imgsz", type=int, default=DEFAULT_IMAGE_SIZE, help="Inference image size")
    parser.add_argument("--conf", type=float, default=DEFAULT_CONFIDENCE, help="Confidence threshold")
    parser.add_argument("--iou", type=float, default=DEFAULT_IOU, help="IoU threshold")
    parser.add_argument("--device", default="auto", help="auto, cpu, 0, 1, ...")
    parser.add_argument("--output", default="outputs", help="Root directory for run artifacts")
    parser.add_argument("--run-name", default="yolo_run", help="Name of the current run")
    parser.add_argument("--max-frames", type=int, default=None, help="Optional frame cap for video/webcam")
    parser.add_argument("--no-display", action="store_true", help="Disable the OpenCV display window")
    parser.add_argument("--no-save", action="store_true", help="Do not save annotated output media")
    return parser


def detect_image(detector: YOLODetector, source: str, run_dir: Path) -> dict:
    frame = cv2.imread(source)
    if frame is None:
        raise FileNotFoundError(f"Could not read image: {source}")

    start = time.perf_counter()
    result = detector.predict(frame)
    end = time.perf_counter()
    summary = detector.summarize(result)
    annotated = detector.annotate(frame, result)

    inference_ms = (end - start) * 1000.0
    annotated = add_metrics_overlay(annotated, 0.0, inference_ms, summary.count, summary.mean_confidence)

    if run_dir:
        ensure_dir(run_dir)
        out_path = run_dir / "annotated_image.jpg"
        cv2.imwrite(str(out_path), annotated)

        tracker = MetricsTracker()
        tracker.record(1, start, start, end, summary.count, summary.mean_confidence)
        save_metrics_csv(tracker.frames, run_dir / "metrics.csv")
        save_summary(tracker.summary(), run_dir / "summary.json")
        save_plots(tracker.frames, run_dir / "plots")

    return tracker.summary() if run_dir else {"detections": summary.count}


def detect_stream(detector: YOLODetector, source, run_dir: Path, display: bool, save_output: bool, max_frames: int | None) -> dict:
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        raise RuntimeError(f"Could not open source: {source}")

    writer = None
    if save_output:
        writer = create_video_writer(cap, run_dir / "annotated_output.mp4")

    tracker = MetricsTracker()
    frame_index = 0

    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            frame_index += 1
            if max_frames is not None and frame_index > max_frames:
                break

            loop_start = time.perf_counter()
            inference_start = time.perf_counter()
            result = detector.predict(frame)
            inference_end = time.perf_counter()
            summary = detector.summarize(result)

            metric = tracker.record(
                frame_index,
                loop_start,
                inference_start,
                inference_end,
                summary.count,
                summary.mean_confidence,
            )
            annotated = detector.annotate(frame, result)
            annotated = add_metrics_overlay(
                annotated,
                metric.fps,
                metric.inference_time_ms,
                summary.count,
                summary.mean_confidence,
            )

            if writer is not None:
                writer.write(annotated)

            if display:
                cv2.imshow("YOLO Real-Time Object Detection", annotated)
                key = cv2.waitKey(1) & 0xFF
                if key in (27, ord("q")):
                    break
    finally:
        cap.release()
        if writer is not None:
            writer.release()
        cv2.destroyAllWindows()

    ensure_dir(run_dir)
    save_metrics_csv(tracker.frames, run_dir / "metrics.csv")
    save_summary(tracker.summary(), run_dir / "summary.json")
    save_plots(tracker.frames, run_dir / "plots")
    return tracker.summary()


def main() -> None:
    args = build_parser().parse_args()
    run_dir = Path(args.output) / args.run_name
    ensure_dir(run_dir)

    detector = YOLODetector(
        model_path=args.model,
        conf=args.conf,
        imgsz=args.imgsz,
        iou=args.iou,
        device=args.device,
    )

    source = parse_source(args.source)
    if isinstance(source, str) and Path(source).suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp", ".webp"}:
        summary = detect_image(detector, source, run_dir if not args.no_save else None)
    else:
        summary = detect_stream(
            detector,
            source,
            run_dir,
            display=not args.no_display,
            save_output=not args.no_save,
            max_frames=args.max_frames,
        )

    print("Run complete")
    for key, value in summary.items():
        print(f"{key}: {value}")


if __name__ == "__main__":
    main()
