from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Iterable

import matplotlib.pyplot as plt

from .metrics import FrameMetrics


def save_metrics_csv(metrics: Iterable[FrameMetrics], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = list(metrics)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "frame_index",
                "wall_time_s",
                "loop_time_ms",
                "inference_time_ms",
                "fps",
                "detections",
                "mean_confidence",
            ],
        )
        writer.writeheader()
        for row in rows:
            writer.writerow(row.__dict__)


def save_summary(summary: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(summary, indent=2), encoding="utf-8")


def _style_axes(ax, title: str, xlabel: str, ylabel: str) -> None:
    ax.set_title(title, fontsize=11, fontweight="bold")
    ax.set_xlabel(xlabel, fontsize=9)
    ax.set_ylabel(ylabel, fontsize=9)
    ax.grid(True, alpha=0.25, linewidth=0.6)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


def save_plots(metrics: list[FrameMetrics], output_dir: Path) -> None:
    if not metrics:
        return
    output_dir.mkdir(parents=True, exist_ok=True)
    x = [m.frame_index for m in metrics]

    fig, ax = plt.subplots(figsize=(8.0, 4.2))
    ax.plot(x, [m.fps for m in metrics], linewidth=1.4)
    _style_axes(ax, "Frame Rate Over Time", "Frame index", "FPS")
    fig.tight_layout()
    fig.savefig(output_dir / "fps_over_frames.png", dpi=180, bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8.0, 4.2))
    ax.plot(x, [m.inference_time_ms for m in metrics], linewidth=1.4)
    _style_axes(ax, "Inference Latency Over Time", "Frame index", "Milliseconds")
    fig.tight_layout()
    fig.savefig(output_dir / "inference_latency.png", dpi=180, bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8.0, 4.2))
    ax.plot(x, [m.detections for m in metrics], linewidth=1.4)
    _style_axes(ax, "Detected Objects Per Frame", "Frame index", "Detections")
    fig.tight_layout()
    fig.savefig(output_dir / "detections_per_frame.png", dpi=180, bbox_inches="tight")
    plt.close(fig)
