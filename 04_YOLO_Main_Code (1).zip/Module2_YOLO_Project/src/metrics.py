from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class FrameMetrics:
    frame_index: int
    wall_time_s: float
    loop_time_ms: float
    inference_time_ms: float
    fps: float
    detections: int
    mean_confidence: float


@dataclass
class MetricsTracker:
    start_time: float = field(default_factory=time.perf_counter)
    previous_time: float | None = None
    frames: list[FrameMetrics] = field(default_factory=list)

    def record(
        self,
        frame_index: int,
        loop_start: float,
        inference_start: float,
        inference_end: float,
        detections: int,
        mean_confidence: float,
    ) -> FrameMetrics:
        now = time.perf_counter()
        loop_ms = (now - loop_start) * 1000.0
        inference_ms = (inference_end - inference_start) * 1000.0

        if self.previous_time is None:
            fps = 0.0
        else:
            delta = max(now - self.previous_time, 1e-9)
            fps = 1.0 / delta
        self.previous_time = now

        metric = FrameMetrics(
            frame_index=frame_index,
            wall_time_s=now - self.start_time,
            loop_time_ms=loop_ms,
            inference_time_ms=inference_ms,
            fps=fps,
            detections=detections,
            mean_confidence=mean_confidence,
        )
        self.frames.append(metric)
        return metric

    def summary(self) -> dict[str, Any]:
        if not self.frames:
            return {"frames": 0}

        inference = [m.inference_time_ms for m in self.frames]
        loop = [m.loop_time_ms for m in self.frames]
        fps = [m.fps for m in self.frames[1:] if m.fps > 0]
        det = [m.detections for m in self.frames]
        conf = [m.mean_confidence for m in self.frames if m.mean_confidence > 0]
        elapsed = self.frames[-1].wall_time_s

        return {
            "frames": len(self.frames),
            "elapsed_seconds": round(elapsed, 4),
            "avg_inference_ms": round(sum(inference) / len(inference), 3),
            "p95_inference_ms": round(percentile(inference, 95), 3),
            "avg_loop_ms": round(sum(loop) / len(loop), 3),
            "avg_fps": round(sum(fps) / len(fps), 3) if fps else 0.0,
            "peak_fps": round(max(fps), 3) if fps else 0.0,
            "avg_detections": round(sum(det) / len(det), 3),
            "mean_confidence": round(sum(conf) / len(conf), 4) if conf else 0.0,
        }


def percentile(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    data = sorted(values)
    rank = (len(data) - 1) * (p / 100.0)
    low = int(rank)
    high = min(low + 1, len(data) - 1)
    fraction = rank - low
    return data[low] + (data[high] - data[low]) * fraction
