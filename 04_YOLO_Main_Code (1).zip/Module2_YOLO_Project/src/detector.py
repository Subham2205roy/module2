from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass
class DetectionSummary:
    count: int
    class_counts: dict[str, int]
    mean_confidence: float


class YOLODetector:
    """Thin wrapper around the Ultralytics YOLO Python API."""

    def __init__(self, model_path: str, conf: float, imgsz: int, iou: float, device: str = "auto") -> None:
        try:
            from ultralytics import YOLO
            import torch
        except ImportError as exc:
            raise RuntimeError(
                "Ultralytics and PyTorch are required. Run `pip install -r requirements.txt` "
                "in an environment with a compatible PyTorch build."
            ) from exc

        self.model = YOLO(model_path)
        self.conf = conf
        self.imgsz = imgsz
        self.iou = iou

        if device == "auto":
            device = "0" if torch.cuda.is_available() else "cpu"
        self.device = device

    def predict(self, frame: np.ndarray) -> Any:
        """Run one-frame inference and return the first Ultralytics Results object."""
        results = self.model.predict(
            source=frame,
            conf=self.conf,
            iou=self.iou,
            imgsz=self.imgsz,
            device=self.device,
            verbose=False,
        )
        return results[0]

    def annotate(self, frame: np.ndarray, result: Any) -> np.ndarray:
        return result.plot(labels=True, conf=True, boxes=True)

    def summarize(self, result: Any) -> DetectionSummary:
        boxes = getattr(result, "boxes", None)
        names = getattr(result, "names", {})
        if boxes is None or len(boxes) == 0:
            return DetectionSummary(count=0, class_counts={}, mean_confidence=0.0)

        cls_values = boxes.cls.detach().cpu().numpy().astype(int).tolist()
        conf_values = boxes.conf.detach().cpu().numpy().astype(float).tolist()
        class_counts = Counter(str(names.get(idx, idx)) for idx in cls_values)
        mean_confidence = float(np.mean(conf_values)) if conf_values else 0.0
        return DetectionSummary(
            count=len(conf_values),
            class_counts=dict(sorted(class_counts.items())),
            mean_confidence=mean_confidence,
        )
