"""Module 2 - Real-Time YOLO Object Detection project."""
