from __future__ import annotations

from pathlib import Path

import cv2


def parse_source(value: str):
    """Interpret a numeric source as a webcam index; otherwise return a path/URL string."""
    try:
        return int(value)
    except ValueError:
        return value


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def create_video_writer(cap: cv2.VideoCapture, output_path: Path) -> cv2.VideoWriter:
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = float(cap.get(cv2.CAP_PROP_FPS))
    if fps <= 0 or fps != fps:
        fps = 25.0

    output_path.parent.mkdir(parents=True, exist_ok=True)
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(str(output_path), fourcc, fps, (width, height))
    if not writer.isOpened():
        raise RuntimeError(f"Could not create video writer at {output_path}")
    return writer
