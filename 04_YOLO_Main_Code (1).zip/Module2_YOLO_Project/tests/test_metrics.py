from src.metrics import MetricsTracker, percentile


def test_percentile_basic():
    assert percentile([10, 20, 30], 50) == 20
    assert percentile([10, 20, 30], 95) > 20


def test_metrics_summary():
    tracker = MetricsTracker(start_time=0.0)
    # Use a deterministic synthetic timing sequence by directly appending metrics.
    from src.metrics import FrameMetrics
    tracker.frames = [
        FrameMetrics(1, 0.1, 20.0, 10.0, 0.0, 2, 0.8),
        FrameMetrics(2, 0.2, 22.0, 12.0, 45.0, 3, 0.7),
        FrameMetrics(3, 0.3, 18.0, 11.0, 50.0, 1, 0.9),
    ]
    summary = tracker.summary()
    assert summary["frames"] == 3
    assert summary["avg_inference_ms"] == 11.0
    assert summary["avg_detections"] == 2.0
    assert summary["mean_confidence"] == 0.8
