from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, FancyArrowPatch

OUT = Path(__file__).resolve().parent


def box(ax, x, y, w, h, text, fs=9, lw=1.2):
    p = FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.015,rounding_size=0.02',
                       linewidth=lw, edgecolor='0.15', facecolor='0.96')
    ax.add_patch(p)
    ax.text(x+w/2, y+h/2, text, ha='center', va='center', fontsize=fs, color='0.1')
    return p


def arrow(ax, x1, y1, x2, y2):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2), arrowstyle='-|>', mutation_scale=12,
                                 linewidth=1.1, color='0.25'))


def save_system():
    fig, ax = plt.subplots(figsize=(12, 4.6))
    ax.set_xlim(0, 12); ax.set_ylim(0, 4.6); ax.axis('off')
    box(ax, .3, 2.9, 1.8, .9, 'Input\nImage / Video /\nCamera', fs=8.2)
    box(ax, 2.65, 2.9, 1.8, .9, 'Pre-processing\nResize + tensor\nconversion', fs=8.2)
    box(ax, 5.0, 2.9, 1.8, .9, 'YOLO Inference\nSingle-stage\ndetector', fs=8.2)
    box(ax, 7.35, 2.9, 1.8, .9, 'Post-processing\nBoxes + classes +\nconfidence', fs=8.0)
    box(ax, 9.7, 2.9, 1.8, .9, 'Output\nAnnotated media +\nmetrics', fs=8.2)
    for a,b in [(2.1,2.65),(4.45,5.0),(6.8,7.35),(9.15,9.7)]: arrow(ax,a,3.35,b,3.35)
    box(ax, 5.0, 1.0, 1.8, .9, 'Performance Analyzer\nLatency + FPS +\ncounts', fs=8.0)
    arrow(ax, 8.25, 2.9, 6.1, 1.9)
    arrow(ax, 6.8, 1.9, 6.8, 2.9)
    ax.text(6, 4.25, 'System Architecture - Real-Time YOLO Detection and Analysis', ha='center', fontsize=13, fontweight='bold', color='0.08')
    fig.savefig(OUT/'system_architecture.png', dpi=220, bbox_inches='tight', facecolor='white')
    plt.close(fig)


def save_pipeline():
    fig, ax = plt.subplots(figsize=(10, 5.6))
    ax.set_xlim(0,10); ax.set_ylim(0,6); ax.axis('off')
    steps=[('Acquire frame',.7,4.6),('Resize to\nmodel input',3.0,4.6),('YOLO model\ninference',5.3,4.6),('Filter by\nconfidence/IoU',7.6,4.6),('Draw results\n+ collect metrics',5.3,2.2),('Save / display\noutput',5.3,.5)]
    for t,x,y in steps: box(ax,x,y,1.7,.9,t,8.5)
    arrow(ax,2.4,5.05,3.0,5.05); arrow(ax,4.7,5.05,5.3,5.05); arrow(ax,7.0,5.05,7.6,5.05)
    arrow(ax,8.45,4.6,6.15,3.1); arrow(ax,6.15,2.2,6.15,1.4)
    ax.text(5,5.75,'Inference Pipeline',ha='center',fontsize=13,fontweight='bold',color='0.08')
    fig.savefig(OUT/'inference_pipeline.png',dpi=220,bbox_inches='tight',facecolor='white')
    plt.close(fig)


def save_benchmark():
    fig, ax = plt.subplots(figsize=(10,5.1))
    ax.set_xlim(0,10); ax.set_ylim(0,5.2); ax.axis('off')
    box(ax,.5,3.4,2.0,.9,'Fixed test source')
    box(ax,3.0,3.4,2.0,.9,'Configuration\n(model / imgsz / conf)')
    box(ax,5.5,3.4,2.0,.9,'Run detector\nN frames')
    box(ax,8.0,3.4,1.5,.9,'Capture\nmetrics')
    arrow(ax,2.5,3.85,3.0,3.85); arrow(ax,5.0,3.85,5.5,3.85); arrow(ax,7.5,3.85,8.0,3.85)
    box(ax,5.5,1.3,2.0,.9,'Aggregate\navg / P95 / peak')
    arrow(ax,8.0,3.4,6.5,2.2)
    box(ax,8.0,1.3,1.5,.9,'Graphs +\nCSV + JSON')
    arrow(ax,7.5,1.75,8.0,1.75)
    ax.text(5,4.8,'Experimental Benchmark Workflow',ha='center',fontsize=13,fontweight='bold',color='0.08')
    fig.savefig(OUT/'benchmark_workflow.png',dpi=220,bbox_inches='tight',facecolor='white')
    plt.close(fig)


def save_folder():
    fig, ax = plt.subplots(figsize=(9.5,5.6))
    ax.set_xlim(0,9.5); ax.set_ylim(0,5.7); ax.axis('off')
    box(ax,.4,4.2,2.0,.8,'src/\ncore application')
    box(ax,3.0,4.2,2.0,.8,'tests/\nunit tests')
    box(ax,5.6,4.2,2.0,.8,'assets/\ndiagrams')
    box(ax,.4,2.2,2.0,.8,'outputs/\nrun artifacts')
    box(ax,3.0,2.2,2.0,.8,'docs/\nreports')
    box(ax,5.6,2.2,2.0,.8,'weights/\noptional checkpoints')
    ax.text(4.75,5.35,'Project Folder Structure',ha='center',fontsize=13,fontweight='bold',color='0.08')
    fig.savefig(OUT/'folder_structure.png',dpi=220,bbox_inches='tight',facecolor='white')
    plt.close(fig)

save_system(); save_pipeline(); save_benchmark(); save_folder()
print('created diagrams')
